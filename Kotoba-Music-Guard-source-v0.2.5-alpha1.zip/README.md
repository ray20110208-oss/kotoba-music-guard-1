# Kotoba Music Guard Probe v0.2.5-alpha1

完全本機的 Android VAD／動態切片測試版。

## 管線

`YouTube 48 kHz PCM → 16 kHz mono → independent voters → evidence fusion → WAV segment`

- 20 ms frames (`320` samples at 16 kHz)
- Chat preset defaults to WebRTC Mode 1
- 300 ms pre-roll
- 6 positive frames in the latest 10 frames to start
- 600 ms trailing silence to finish
- 8 second hard maximum
- Short, high-confidence utterances are retained
- Only the five most recent kept segments are cached
- No `INTERNET` permission; no audio leaves the phone
- Incremental 1024-point STFT and four-second feature history
- Separate background-music and foreground-voice evidence
- Sustained high-confidence music lock (speech harmonics alone cannot lock it)
- Flux-z plus voice-band onset detection with a 500 ms override
- 160 ms cooldown re-arming; raw FFT residual is diagnostic-only
- WebRTC VAD proposes candidates; it never owns the final decision
- YAMNet Speech and Music use the mean of the latest three distinct inferences
- Independent speech and music axes preserve the valid BGM-plus-speech state
- Evidence Council returns SEND, AMBIGUOUS or SUPPRESS with a reason
- Active segments receive no unconditional bypass; sustained music consensus can end them
- Local diagnostic CSV with manual test labels
- YAMNet classifier over a rolling 975 ms window every 500 ms
- Top-5 AudioSet labels plus Speech/Music/Game scores and inference timing
- YAMNet failure or warm-up degrades safely to AMBIGUOUS

## Test procedure

1. Start Kotoba VAD Probe and grant media projection.
2. Play the same 10–15 minute archived Japanese chat stream for repeatable tests.
3. Return to the app or use split screen to inspect state, noise floor, gate and segment counts.
4. Play the latest segment and note clipped starts, early endings, merged sentences and false triggers.

## v0.2.5-alpha1 acceptance checks

- Pure BGM: after three YAMNet votes, Decision should become SUPPRESS and active segments should close.
- Speech plus light game audio: Decision should remain SEND or AMBIGUOUS while the host talks.
- BGM plus speech: Speech and Music evidence may both be high; the segment must not be suppressed.
- Repeated speech must remain distinguishable from pure music.
- Run 30–60 minutes and inspect YAMNet average/max inference time, dropped windows and battery temperature.
- Use the on-screen labels while testing, then export the diagnostic CSV for parameter tuning.

## Third-party component

WebRTC VAD is integrated through `gkonovalov/android-vad` 2.0.10 (MIT), selected for its small
on-device footprint and Android 16 KB page compatibility.

YAMNet and TensorFlow Lite Task Audio 0.4.4 run locally as a diagnostic shadow classifier.
The bundled model is stored uncompressed so the Android runtime can memory-map it.

## Build

The project includes Gradle Wrapper 8.10.2. With JDK 17 and Android SDK 35 installed:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

If an offline build host has not cached Gradle 8.10.2 and Android SDK 35,
allow the first build to download them before switching back to offline mode.

## Backend skeleton

`backend/` contains a dependency-free Node.js 20 service contract. It keeps the API key server-side and fixes the model roles to:

```text
ASR: gpt-4o-mini-transcribe
Fast translation: gpt-4o-mini
Optional second translation: gpt-5.6-luna
```

The v0.2.5 diagnostic APK intentionally remains offline until evidence fusion passes real-device testing.
