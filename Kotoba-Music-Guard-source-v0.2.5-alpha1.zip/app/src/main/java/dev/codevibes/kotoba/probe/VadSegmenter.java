package dev.codevibes.kotoba.probe;

import com.konovalov.vad.webrtc.Vad;
import com.konovalov.vad.webrtc.VadWebRTC;
import com.konovalov.vad.webrtc.config.FrameSize;
import com.konovalov.vad.webrtc.config.Mode;
import com.konovalov.vad.webrtc.config.SampleRate;

import java.io.ByteArrayOutputStream;
import java.util.ArrayDeque;

final class VadSegmenter implements AutoCloseable {
    interface Listener {
        void onFrame(Status status);
        void onSegment(Segment segment);
    }

    static final class Status {
        final String state;
        final double db;
        final double noiseDb;
        final double gateDb;
        final boolean speech;
        final boolean gatePass;
        final boolean rawVad;
        final boolean rawCandidate;
        final MusicGuard.Result music;
        final EvidenceFusion.Result fusion;
        Status(String state, double db, double noiseDb, double gateDb, boolean speech,
               boolean gatePass, boolean rawVad, boolean rawCandidate, MusicGuard.Result music,
               EvidenceFusion.Result fusion) {
            this.state = state; this.db = db; this.noiseDb = noiseDb;
            this.gateDb = gateDb; this.speech = speech; this.gatePass = gatePass;
            this.rawVad = rawVad; this.rawCandidate = rawCandidate; this.music = music;
            this.fusion = fusion;
        }
    }

    static final class Segment {
        final short[] samples;
        final int totalMs;
        final int coreSpeechMs;
        final double coreSpeechRatio;
        final double peakDb;
        final boolean kept;
        final String reason;
        Segment(short[] samples, int totalMs, int coreSpeechMs, double ratio,
                double peakDb, boolean kept, String reason) {
            this.samples = samples; this.totalMs = totalMs; this.coreSpeechMs = coreSpeechMs;
            this.coreSpeechRatio = ratio; this.peakDb = peakDb; this.kept = kept; this.reason = reason;
        }
    }

    private enum State { SILENCE, CANDIDATE, SPEAKING, PAUSING }
    private static final int FRAME_SAMPLES = 320;
    private static final int FRAME_MS = 20;
    private static final int PRE_ROLL_FRAMES = 15;
    private static final int HISTORY_FRAMES = 10;
    private static final int START_REQUIRED = 6;
    private static final int END_SILENCE_FRAMES = 30;
    private static final int MAX_SEGMENT_FRAMES = 400;

    private final Listener listener;
    private final VadWebRTC vad;
    private final MusicGuard musicGuard = new MusicGuard();
    private final EvidenceFusion evidenceFusion = new EvidenceFusion();
    private final ArrayDeque<short[]> preRoll = new ArrayDeque<>();
    private final boolean[] history = new boolean[HISTORY_FRAMES];
    private final ByteArrayOutputStream segmentBytes = new ByteArrayOutputStream();
    private State state = State.SILENCE;
    private int historyCursor;
    private int historySpeech;
    private int segmentFrames;
    private int rawSpeechFrames;
    private int trailingSilenceFrames;
    private double peakDb = -120.0;
    private double noiseDb = -60.0;
    private int frameCounter;
    private int probeHoldFrames;

    VadSegmenter(int preset, Listener listener) {
        this.listener = listener;
        Mode mode = preset == 3 ? Mode.VERY_AGGRESSIVE : preset == 2 ? Mode.AGGRESSIVE : Mode.LOW_BITRATE;
        vad = Vad.builder()
                .setSampleRate(SampleRate.SAMPLE_RATE_16K)
                .setFrameSize(FrameSize.FRAME_SIZE_320)
                .setMode(mode)
                .setSpeechDurationMs(0)
                .setSilenceDurationMs(0)
                .build();
    }

    void accept(short[] frame, YamnetShadowClassifier.Snapshot yamnet) {
        if (frame.length != FRAME_SAMPLES) return;
        frameCounter++;
        double db = dbfs(frame);
        double gateDb = Math.max(-55.0, noiseDb + 6.0);
        boolean gatePass = db >= gateDb;
        boolean probe = frameCounter % 5 == 0;
        if (probeHoldFrames > 0) probeHoldFrames--;
        boolean rawVad = (gatePass || probe || probeHoldFrames > 0) && vad.isSpeech(frame);
        boolean rawCandidate = rawVad;
        // Probe-only positives never refresh themselves. Only a frame that genuinely
        // crosses the adaptive energy gate may open or extend the hold window.
        if (rawCandidate && gatePass) probeHoldFrames = 15;
        MusicGuard.Result music = musicGuard.accept(frame, rawCandidate, db, noiseDb);
        EvidenceFusion.Result fusion = evidenceFusion.vote(rawVad, gatePass, music, yamnet);
        // WebRTC proposes a candidate. The evidence council may suppress only
        // after three distinct YAMNet observations agree with sustained music.
        // Active segments receive no unconditional bypass.
        boolean rawSpeech = rawCandidate && fusion.verdict != EvidenceFusion.Verdict.SUPPRESS;

        // A confirmed, stable music bed is allowed to become part of the background
        // model. Music Guard may raise the threshold for starting a segment, but
        // once speech starts ordinary VAD owns continuation through the sentence.
        if (state == State.SILENCE && (!rawCandidate || (music.backgroundMusic && !music.voiceOverride))) {
            double alpha = db > noiseDb ? 0.02 : 0.004;
            double next = noiseDb + alpha * (db - noiseDb);
            noiseDb = clamp(next, noiseDb - 0.20, noiseDb + 0.50);
            noiseDb = clamp(noiseDb, -75.0, -25.0);
        }

        updateHistory(rawSpeech);
        if (state == State.SILENCE || state == State.CANDIDATE) {
            pushPreRoll(frame);
            state = historySpeech > 0 ? State.CANDIDATE : State.SILENCE;
            if (historySpeech >= START_REQUIRED) beginSegment(db);
        } else {
            appendFrame(frame);
            if (rawSpeech) {
                rawSpeechFrames++;
                trailingSilenceFrames = 0;
                state = State.SPEAKING;
            } else {
                trailingSilenceFrames++;
                state = State.PAUSING;
            }
            peakDb = Math.max(peakDb, db);
            if (trailingSilenceFrames >= END_SILENCE_FRAMES) finishSegment("停頓結束");
            else if (segmentFrames >= MAX_SEGMENT_FRAMES) finishSegment("達到 8 秒上限");
        }
        listener.onFrame(new Status(label(state), db, noiseDb, gateDb, rawSpeech,
                gatePass, rawVad, rawCandidate, music, fusion));
    }

    private void beginSegment(double db) {
        segmentBytes.reset();
        segmentFrames = 0; rawSpeechFrames = historySpeech; trailingSilenceFrames = 0; peakDb = db;
        for (short[] buffered : preRoll) appendFrame(buffered);
        preRoll.clear();
        state = State.SPEAKING;
    }

    private void finishSegment(String reason) {
        int totalFrames = segmentFrames;
        // Five frames are guaranteed look-back padding; the latest ten frames form the
        // start vote and may legitimately contain the beginning of a short utterance.
        int leadingPaddingFrames = Math.max(0, PRE_ROLL_FRAMES - HISTORY_FRAMES);
        int coreFrames = Math.max(1, totalFrames - leadingPaddingFrames - trailingSilenceFrames);
        int coreSpeechMs = rawSpeechFrames * FRAME_MS;
        double ratio = Math.min(1.0, rawSpeechFrames / (double) coreFrames);
        boolean shortButClear = coreSpeechMs >= 200 && ratio >= 0.60;
        boolean normalSpeech = coreSpeechMs >= 400 && ratio >= 0.35;
        boolean kept = shortButClear || normalSpeech;
        String decision = kept ? reason : "丟棄：核心人聲不足";
        listener.onSegment(new Segment(toShortArray(segmentBytes.toByteArray()),
                totalFrames * FRAME_MS, coreSpeechMs, ratio, peakDb, kept, decision));
        segmentBytes.reset(); segmentFrames = 0; rawSpeechFrames = 0;
        trailingSilenceFrames = 0; peakDb = -120.0;
        clearHistory(); state = State.SILENCE;
    }

    private void appendFrame(short[] frame) {
        for (short sample : frame) {
            segmentBytes.write(sample & 0xff);
            segmentBytes.write((sample >>> 8) & 0xff);
        }
        segmentFrames++;
    }

    private void pushPreRoll(short[] frame) {
        preRoll.addLast(frame.clone());
        while (preRoll.size() > PRE_ROLL_FRAMES) preRoll.removeFirst();
    }

    private void updateHistory(boolean speech) {
        if (history[historyCursor]) historySpeech--;
        history[historyCursor] = speech;
        if (speech) historySpeech++;
        historyCursor = (historyCursor + 1) % HISTORY_FRAMES;
    }

    private void clearHistory() {
        for (int i = 0; i < history.length; i++) history[i] = false;
        historySpeech = 0; historyCursor = 0; preRoll.clear();
    }

    private static double dbfs(short[] frame) {
        double sum = 0;
        for (short value : frame) { double n = value / 32768.0; sum += n * n; }
        double rms = Math.sqrt(sum / frame.length);
        return rms > 0 ? 20.0 * Math.log10(rms) : -120.0;
    }

    private static short[] toShortArray(byte[] bytes) {
        short[] output = new short[bytes.length / 2];
        for (int i = 0; i < output.length; i++)
            output[i] = (short) ((bytes[i * 2] & 0xff) | (bytes[i * 2 + 1] << 8));
        return output;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String label(State state) {
        switch (state) {
            case CANDIDATE: return "可能有人聲";
            case SPEAKING: return "說話中";
            case PAUSING: return "等待句尾";
            default: return "靜音／背景聲";
        }
    }

    @Override public void close() { vad.close(); }
}
