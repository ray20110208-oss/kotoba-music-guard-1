# Third-party notices

## Android VAD

- Project: `gkonovalov/android-vad`
- Version: 2.0.10
- License: MIT
- Source: https://github.com/gkonovalov/android-vad

The release AAR contains the WebRTC VAD native implementation and its Java/Kotlin API.

## YAMNet

- Project: TensorFlow Models YAMNet
- Model: `yamnet.tflite` bundled by `gkonovalov/android-vad` 2.0.10
- License: Apache License 2.0
- Source: https://github.com/tensorflow/models/tree/master/research/audioset/yamnet

The complete model license is included in the APK assets as `YAMNET_LICENSE`.

## TensorFlow Lite Task Audio

- Artifact: `org.tensorflow:tensorflow-lite-task-audio`
- Version: 0.4.4
- License: Apache License 2.0
- Source: https://www.tensorflow.org/lite/inference_with_metadata/task_library/audio_classifier

The source archive includes the pinned runtime AARs and their Maven metadata for reproducible builds.
