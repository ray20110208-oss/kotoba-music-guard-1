package dev.codevibes.kotoba.probe;

/** Lightweight 48 kHz to 16 kHz converter for mono PCM16 diagnostic audio. */
final class AudioResampler {
    private final short[] carry = new short[2];
    private int carryCount;

    short[] downsample48To16(short[] input, int count) {
        int combinedCount = carryCount + count;
        short[] combined = new short[combinedCount];
        System.arraycopy(carry, 0, combined, 0, carryCount);
        System.arraycopy(input, 0, combined, carryCount, count);
        int outputCount = combinedCount / 3;
        short[] output = new short[outputCount];
        for (int i = 0; i < outputCount; i++) {
            int p = i * 3;
            // A tiny triangular filter reduces aliasing before 3:1 decimation.
            output[i] = (short) ((combined[p] + 2 * combined[p + 1] + combined[p + 2]) / 4);
        }
        carryCount = combinedCount - outputCount * 3;
        for (int i = 0; i < carryCount; i++) carry[i] = combined[outputCount * 3 + i];
        return output;
    }
}
