package dev.codevibes.kotoba.probe;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;

final class DiagnosticLogger implements AutoCloseable {
    private final File file;
    private final BufferedWriter writer;
    private long row;

    DiagnosticLogger(File directory) throws IOException {
        file = new File(directory, "kotoba-v025-evidence-fusion.csv");
        writer = new BufferedWriter(new FileWriter(file, false));
        writer.write("timestamp_ms,preset,vad_mode,db,noise_db,gate_db,gate_pass,raw_vad,raw_candidate,accepted_speech,vad_ratio,energy_variation,zcr_mean,zcr_variation,spectral_flux,harmonic_persistence,rhythm_periodicity,background_music_score,foreground_voice_score,energy_delta,flux_z,spectrum_residual,voice_band_delta,background_music,background_ready,voice_onset,voice_override,armed,override_frames,speech_evidence,music_evidence,yamnet_speech_rolling,yamnet_music_rolling,fusion_ready,decision,decision_reason,state,processing_us,yamnet_ready,yamnet_top_label,yamnet_top_score,yamnet_speech_score,yamnet_music_score,yamnet_game_score,yamnet_top5,yamnet_last_ms,yamnet_avg_ms,yamnet_max_ms,yamnet_count,yamnet_dropped,yamnet_error,label\n");
        writer.flush();
    }

    File getFile() { return file; }

    void log(VadSegmenter.Status s, YamnetShadowClassifier.Snapshot y,
             int preset, int vadMode) {
        if ((row++ % 13) != 0) return;
        try {
            writer.write(String.format(Locale.US,
                    "%d,%d,%d,%.3f,%.3f,%.3f,%b,%b,%b,%b,%.4f,%.4f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.5f,%.4f,%.4f,%.4f,%.4f,%b,%b,%b,%b,%b,%d,%.4f,%.4f,%.4f,%.4f,%b,%s,%s,%s,%.2f,%b,%s,%.4f,%.4f,%.4f,%.4f,%s,%.3f,%.3f,%.3f,%d,%d,%s,\n",
                    System.currentTimeMillis(), preset, vadMode, s.db, s.noiseDb, s.gateDb, s.gatePass,
                    s.rawVad, s.rawCandidate, s.speech, s.music.vadRatio,
                    s.music.energyVariation, s.music.zcrMean, s.music.zcrVariation,
                    s.music.spectralFlux, s.music.harmonicPersistence,
                    s.music.rhythmPeriodicity, s.music.backgroundMusicScore,
                    s.music.foregroundVoiceScore, s.music.energyDelta, s.music.fluxZ,
                    s.music.spectrumResidual, s.music.voiceBandDelta,
                    s.music.backgroundMusic, s.music.backgroundReady, s.music.voiceOnset,
                    s.music.voiceOverride, s.music.armed, s.music.overrideFrames,
                    s.fusion.speechEvidence, s.fusion.musicEvidence,
                    s.fusion.yamnetSpeechRolling, s.fusion.yamnetMusicRolling,
                    s.fusion.yamnetHistoryReady, s.fusion.verdict.name(), clean(s.fusion.reason),
                    s.state.replace(',', '_'), s.music.processingNanos / 1000.0,
                    y.ready, clean(y.topLabel), y.topScore, y.speechScore, y.musicScore,
                    y.gameScore, clean(y.topFive), y.inferenceMs, y.averageMs, y.maxMs,
                    y.inferenceCount, y.droppedWindows, clean(y.error)));
            writer.flush();
        } catch (IOException ignored) {}
    }

    static void appendLabel(File file, String label) throws IOException {
        BufferedWriter out = new BufferedWriter(new FileWriter(file, true));
        out.write(String.format(Locale.US,
                "%d,,,,,,,,,,,,,,,,,,,,,,,,,,,,0,,,,,,,,,,,,,,%s\n", System.currentTimeMillis(), label));
        out.close();
    }

    @Override public void close() {
        try { writer.close(); } catch (IOException ignored) {}
    }

    private static String clean(String value) {
        return value == null ? "" : value.replace(',', '/').replace('\n', ' ').replace('\r', ' ');
    }
}
