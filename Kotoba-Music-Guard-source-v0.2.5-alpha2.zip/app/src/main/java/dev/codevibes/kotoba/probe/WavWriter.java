package dev.codevibes.kotoba.probe;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

final class WavWriter {
    private WavWriter() {}

    static void writeMono16(File file, short[] samples, int sampleRate) throws IOException {
        int dataBytes = samples.length * 2;
        try (FileOutputStream out = new FileOutputStream(file)) {
            writeAscii(out, "RIFF"); writeInt(out, 36 + dataBytes); writeAscii(out, "WAVE");
            writeAscii(out, "fmt "); writeInt(out, 16); writeShort(out, 1); writeShort(out, 1);
            writeInt(out, sampleRate); writeInt(out, sampleRate * 2); writeShort(out, 2); writeShort(out, 16);
            writeAscii(out, "data"); writeInt(out, dataBytes);
            for (short sample : samples) writeShort(out, sample);
        }
    }

    private static void writeAscii(FileOutputStream out, String value) throws IOException {
        out.write(value.getBytes("US-ASCII"));
    }
    private static void writeShort(FileOutputStream out, int value) throws IOException {
        out.write(value & 0xff); out.write((value >>> 8) & 0xff);
    }
    private static void writeInt(FileOutputStream out, int value) throws IOException {
        out.write(value & 0xff); out.write((value >>> 8) & 0xff);
        out.write((value >>> 16) & 0xff); out.write((value >>> 24) & 0xff);
    }
}
