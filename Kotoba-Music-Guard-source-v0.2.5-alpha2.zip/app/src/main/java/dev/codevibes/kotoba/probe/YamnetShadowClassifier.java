package dev.codevibes.kotoba.probe;

import android.content.Context;

import org.tensorflow.lite.support.audio.TensorAudio;
import org.tensorflow.lite.support.label.Category;
import org.tensorflow.lite.task.audio.classifier.AudioClassifier;
import org.tensorflow.lite.task.audio.classifier.Classifications;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runs YAMNet asynchronously. v0.2.5 consumes its rolling Speech/Music evidence,
 * while a model failure safely degrades to AMBIGUOUS instead of blocking audio.
 */
final class YamnetShadowClassifier implements AutoCloseable {
    static final class Snapshot {
        static final Snapshot STARTING = new Snapshot(false, "初始化中", 0, 0, 0, 0,
                "", 0, 0, 0, 0, 0, "");

        final boolean ready;
        final String topLabel;
        final double topScore, speechScore, musicScore, gameScore;
        final String topFive;
        final double inferenceMs, averageMs, maxMs;
        final long inferenceCount, droppedWindows;
        final String error;

        Snapshot(boolean ready, String topLabel, double topScore,
                 double speechScore, double musicScore, double gameScore,
                 String topFive, double inferenceMs, double averageMs, double maxMs,
                 long inferenceCount, long droppedWindows, String error) {
            this.ready = ready;
            this.topLabel = topLabel;
            this.topScore = topScore;
            this.speechScore = speechScore;
            this.musicScore = musicScore;
            this.gameScore = gameScore;
            this.topFive = topFive;
            this.inferenceMs = inferenceMs;
            this.averageMs = averageMs;
            this.maxMs = maxMs;
            this.inferenceCount = inferenceCount;
            this.droppedWindows = droppedWindows;
            this.error = error;
        }
    }

    private static final int WINDOW_SAMPLES = 15_600; // YAMNet: about 975 ms at 16 kHz
    private static final int UPDATE_FRAMES = 25;      // one inference every 500 ms

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "kotoba-yamnet-shadow");
        thread.setPriority(Thread.NORM_PRIORITY - 1);
        return thread;
    });
    private final AtomicBoolean inferencePending = new AtomicBoolean();
    private final short[] ring = new short[WINDOW_SAMPLES];
    private int ringCursor, ringFill, frameCounter;
    private volatile AudioClassifier classifier;
    private volatile TensorAudio tensor;
    private volatile Snapshot snapshot = Snapshot.STARTING;
    private volatile boolean closed;
    private long inferenceCount, droppedWindows;
    private double averageMs, maxMs;

    YamnetShadowClassifier(Context context) {
        Context appContext = context.getApplicationContext();
        executor.execute(() -> initialize(appContext));
    }

    private void initialize(Context context) {
        try {
            AudioClassifier.AudioClassifierOptions options =
                    AudioClassifier.AudioClassifierOptions.builder()
                            .setMaxResults(5)
                            .setScoreThreshold(0.01f)
                            .build();
            AudioClassifier created = AudioClassifier.createFromFileAndOptions(
                    context, "yamnet.tflite", options);
            TensorAudio input = created.createInputTensorAudio();
            classifier = created;
            tensor = input;
            snapshot = new Snapshot(true, "等待首個窗口", 0, 0, 0, 0,
                    "", 0, 0, 0, 0, 0, "");
        } catch (Throwable error) {
            snapshot = failure(error);
        }
    }

    void accept(short[] frame) {
        if (closed) return;
        for (short sample : frame) {
            ring[ringCursor] = sample;
            ringCursor = (ringCursor + 1) % ring.length;
            if (ringFill < ring.length) ringFill++;
        }
        if (++frameCounter < UPDATE_FRAMES) return;
        frameCounter = 0;
        if (ringFill < ring.length || classifier == null || tensor == null) return;
        if (!inferencePending.compareAndSet(false, true)) {
            droppedWindows++;
            return;
        }
        short[] window = new short[ring.length];
        int tail = ring.length - ringCursor;
        System.arraycopy(ring, ringCursor, window, 0, tail);
        System.arraycopy(ring, 0, window, tail, ringCursor);
        executor.execute(() -> classify(window));
    }

    private void classify(short[] window) {
        long started = System.nanoTime();
        try {
            TensorAudio input = tensor;
            AudioClassifier model = classifier;
            if (closed || input == null || model == null) return;
            input.load(window);
            List<Classifications> heads = model.classify(input);
            List<Category> categories = heads.isEmpty()
                    ? java.util.Collections.emptyList() : heads.get(0).getCategories();
            double speech = 0, music = 0, game = 0;
            String topLabel = "未分類";
            double topScore = 0;
            StringBuilder topFive = new StringBuilder();
            for (int i = 0; i < categories.size() && i < 5; i++) {
                Category category = categories.get(i);
                String label = category.getLabel() == null ? "" : category.getLabel();
                double score = category.getScore();
                if (i == 0) { topLabel = label; topScore = score; }
                if (isSpeech(label)) speech = Math.max(speech, score);
                if (isMusic(label)) music = Math.max(music, score);
                if (isGameOrEffect(label)) game = Math.max(game, score);
                if (topFive.length() > 0) topFive.append('|');
                topFive.append(sanitize(label)).append(':')
                        .append(String.format(Locale.US, "%.3f", score));
            }
            double elapsedMs = (System.nanoTime() - started) / 1_000_000.0;
            inferenceCount++;
            averageMs += (elapsedMs - averageMs) / inferenceCount;
            maxMs = Math.max(maxMs, elapsedMs);
            snapshot = new Snapshot(true, sanitize(topLabel), topScore,
                    speech, music, game, topFive.toString(), elapsedMs,
                    averageMs, maxMs, inferenceCount, droppedWindows, "");
        } catch (Throwable error) {
            snapshot = failure(error);
        } finally {
            inferencePending.set(false);
        }
    }

    Snapshot snapshot() { return snapshot; }

    private Snapshot failure(Throwable error) {
        String message = error.getClass().getSimpleName();
        if (error.getMessage() != null && !error.getMessage().isEmpty())
            message += ": " + error.getMessage();
        return new Snapshot(false, "YAMNet 錯誤", 0, 0, 0, 0, "",
                0, averageMs, maxMs, inferenceCount, droppedWindows, sanitize(message));
    }

    private static boolean isSpeech(String label) {
        String value = label.toLowerCase(Locale.US);
        return value.contains("speech") || value.contains("conversation")
                || value.contains("narration") || value.contains("monologue")
                || value.contains("speaking") || value.contains("whispering");
    }

    private static boolean isMusic(String label) {
        String value = label.toLowerCase(Locale.US);
        return value.contains("music") || value.contains("singing")
                || value.contains("song") || value.contains("musical instrument")
                || value.contains("guitar") || value.contains("piano")
                || value.contains("drum") || value.contains("violin")
                || value.contains("orchestra") || value.contains("choir")
                || value.contains("rock") || value.contains("pop")
                || value.contains("jazz") || value.contains("electronic");
    }

    private static boolean isGameOrEffect(String label) {
        String value = label.toLowerCase(Locale.US);
        return value.contains("video game") || value.contains("sound effect")
                || value.contains("gunshot") || value.contains("explosion")
                || value.contains("vehicle") || value.contains("engine");
    }

    private static String sanitize(String value) {
        return value == null ? "" : value.replace(',', '/').replace('\n', ' ').replace('\r', ' ');
    }

    @Override public void close() {
        closed = true;
        executor.execute(() -> {
            AudioClassifier model = classifier;
            classifier = null;
            tensor = null;
            if (model != null) try { model.close(); } catch (Throwable ignored) {}
        });
        executor.shutdown();
    }
}
