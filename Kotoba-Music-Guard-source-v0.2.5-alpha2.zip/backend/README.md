# Kotoba backend skeleton

Node.js 20+ service that keeps the OpenAI API key off the Android device.

## Environment

```text
OPENAI_API_KEY=required for model calls
KOTOBA_APP_TOKEN=recommended shared app-to-backend bearer token
PORT=8787 by default
```

## Routes

- `GET /health` — service status; never exposes the API key.
- `POST /v1/process?segmentId=...` — raw `audio/wav` body; returns Japanese source plus the fast Traditional Chinese translation.
- `POST /v1/retranslate` — JSON `{segmentId, sourceText, context[]}`; returns an independent Luna translation.

Models are fixed server-side:

```text
ASR: gpt-4o-mini-transcribe
Fast translation: gpt-4o-mini
Optional second translation: gpt-5.6-luna
```

The Android v0.2.4 diagnostic APK intentionally has no network permission and is not connected to these routes yet.
