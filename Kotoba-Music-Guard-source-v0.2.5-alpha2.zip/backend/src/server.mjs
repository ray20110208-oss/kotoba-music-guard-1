import { createServer } from "node:http";

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const APP_TOKEN = process.env.KOTOBA_APP_TOKEN || "";
const MAX_AUDIO_BYTES = 4 * 1024 * 1024;
const MAX_JSON_BYTES = 128 * 1024;

function json(response, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": data.length,
    "cache-control": "no-store"
  });
  response.end(data);
}

function authorized(request) {
  if (!APP_TOKEN) return true;
  return request.headers.authorization === `Bearer ${APP_TOKEN}`;
}

async function readBody(request, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error("request_too_large"), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function openai(path, options) {
  if (!OPENAI_API_KEY) throw Object.assign(new Error("OPENAI_API_KEY is not configured"), { status: 503 });
  const response = await fetch(`https://api.openai.com${path}`, {
    ...options,
    headers: { authorization: `Bearer ${OPENAI_API_KEY}`, ...(options.headers || {}) },
    signal: AbortSignal.timeout(25_000)
  });
  const data = await response.json();
  if (!response.ok) {
    const message = data?.error?.message || `OpenAI request failed (${response.status})`;
    throw Object.assign(new Error(message), { status: 502 });
  }
  return data;
}

async function transcribe(wav) {
  const form = new FormData();
  form.append("file", new Blob([wav], { type: "audio/wav" }), "segment.wav");
  form.append("model", "gpt-4o-mini-transcribe");
  form.append("language", "ja");
  form.append("response_format", "json");
  const result = await openai("/v1/audio/transcriptions", { method: "POST", body: form });
  return String(result.text || "").trim();
}

function responseText(result) {
  if (typeof result.output_text === "string") return result.output_text.trim();
  for (const item of result.output || [])
    for (const content of item.content || [])
      if (content.type === "output_text" && content.text) return content.text.trim();
  return "";
}

async function translate(sourceText, context, refined) {
  const model = refined ? "gpt-5.6-luna" : "gpt-4o-mini";
  const instructions = refined
    ? "Translate Japanese livestream speech into natural Traditional Chinese used in Taiwan. Preserve tone, implied subjects, jokes and gaming context. Re-translate independently from Japanese; output only the translation."
    : "Translate Japanese livestream speech into concise Traditional Chinese used in Taiwan. Preserve meaning and tone. Output only the translation.";
  const input = context?.length
    ? `Previous Japanese context:\n${context.slice(-3).join("\n")}\n\nCurrent Japanese:\n${sourceText}`
    : sourceText;
  const result = await openai("/v1/responses", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ model, instructions, input })
  });
  return { model, text: responseText(result) };
}

const server = createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/health")
      return json(response, 200, { ok: true, apiConfigured: Boolean(OPENAI_API_KEY) });
    if (!authorized(request)) return json(response, 401, { error: "unauthorized" });

    const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
    if (request.method === "POST" && url.pathname === "/v1/process") {
      const segmentId = url.searchParams.get("segmentId") || crypto.randomUUID();
      const wav = await readBody(request, MAX_AUDIO_BYTES);
      const sourceText = await transcribe(wav);
      if (!sourceText) return json(response, 200, { segmentId, sourceText: "", translation: "", filtered: true });
      const translated = await translate(sourceText, [], false);
      return json(response, 200, {
        segmentId,
        sourceText,
        translation: translated.text,
        translationModel: translated.model,
        filtered: false
      });
    }

    if (request.method === "POST" && url.pathname === "/v1/retranslate") {
      const body = JSON.parse((await readBody(request, MAX_JSON_BYTES)).toString("utf8"));
      if (!body.segmentId || !body.sourceText) return json(response, 400, { error: "segmentId_and_sourceText_required" });
      const translated = await translate(String(body.sourceText), Array.isArray(body.context) ? body.context : [], true);
      return json(response, 200, {
        segmentId: String(body.segmentId),
        translation: translated.text,
        translationModel: translated.model
      });
    }

    return json(response, 404, { error: "not_found" });
  } catch (error) {
    const status = Number(error.status) || 500;
    json(response, status, { error: status >= 500 ? "service_error" : error.message });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Kotoba backend listening on :${PORT}`);
});
