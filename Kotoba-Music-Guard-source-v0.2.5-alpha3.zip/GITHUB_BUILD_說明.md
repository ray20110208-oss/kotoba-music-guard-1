# 用 GitHub 雲端建置 APK

## 第一次上傳

1. 在 GitHub 右上角按 `+`，選擇 `New repository`。
2. Repository name 可填 `kotoba-music-guard`，選擇 Private 或 Public 均可。
3. 不要勾選新增 README、`.gitignore` 或 License，直接建立空白 repository。
4. 解壓本 ZIP，進入 `kotoba-v0.2` 資料夾。
5. 按 GitHub 空白 repository 頁面的 `uploading an existing file`。
6. 將 `kotoba-v0.2` 裡面的所有內容拖入上傳區；必須讓 `.github`、`app`、`gradle` 與 `gradlew` 位於 repository 最上層。
7. 按 `Commit changes`。

## 取得 APK

1. 打開 repository 上方的 `Actions`。
2. 若 GitHub 詢問是否啟用 Actions，按下啟用。
3. 點選左側 `Build Kotoba APK`。
4. 第一次上傳通常會自動開始；否則按 `Run workflow`。
5. 等待綠色勾勾出現，打開該次執行結果。
6. 在頁面底部 `Artifacts` 下載 `Kotoba-Music-Guard-v0.2.5-alpha3`。
7. 解壓下載的 Artifact，裡面的 `app-debug.apk` 就是安裝檔。

APK 是 debug 簽章版本。若手機上已有不同簽章的舊版本，Android 可能要求先移除舊版再安裝。
