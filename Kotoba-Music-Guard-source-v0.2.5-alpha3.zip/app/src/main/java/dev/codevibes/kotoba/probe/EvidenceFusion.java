package dev.codevibes.kotoba.probe;

import java.util.ArrayDeque;

/** Combines independent observations. No individual detector owns the verdict. */
final class EvidenceFusion {
    enum Verdict { SEND, AMBIGUOUS, SUPPRESS }

    static final class Result {
        final double speechEvidence;
        final double musicEvidence;
        final double yamnetSpeechRolling;
        final double yamnetMusicRolling;
        final boolean yamnetHistoryReady;
        final Verdict verdict;
        final String reason;

        Result(double speechEvidence, double musicEvidence,
               double yamnetSpeechRolling, double yamnetMusicRolling,
               boolean yamnetHistoryReady, Verdict verdict, String reason) {
            this.speechEvidence = speechEvidence;
            this.musicEvidence = musicEvidence;
            this.yamnetSpeechRolling = yamnetSpeechRolling;
            this.yamnetMusicRolling = yamnetMusicRolling;
            this.yamnetHistoryReady = yamnetHistoryReady;
            this.verdict = verdict;
            this.reason = reason;
        }
    }

    private final ArrayDeque<Double> speechHistory = new ArrayDeque<>();
    private final ArrayDeque<Double> musicHistory = new ArrayDeque<>();
    private final boolean bgmPreset;
    private long lastInferenceCount = -1;

    EvidenceFusion(int preset) {
        bgmPreset = preset == 4;
    }

    Result vote(boolean rawVad, boolean gatePass, MusicGuard.Result guard,
                YamnetShadowClassifier.Snapshot yamnet) {
        if (yamnet.ready && yamnet.inferenceCount > 0
                && yamnet.inferenceCount != lastInferenceCount) {
            lastInferenceCount = yamnet.inferenceCount;
            push(speechHistory, yamnet.speechScore);
            push(musicHistory, yamnet.musicScore);
        }

        double speechRolling = mean(speechHistory);
        double musicRolling = mean(musicHistory);
        boolean ready = speechHistory.size() >= 3;

        // Each voter speaks in its own domain. Music evidence never subtracts
        // speech evidence because speech over music is a legitimate scene.
        double yamnetSpeechVote = clamp01((speechRolling - 0.03) / 0.27);
        double webRtcVote = rawVad ? (gatePass ? 1.0 : 0.65) : 0.0;
        double foregroundVote = clamp01(guard.foregroundVoiceScore / 0.55);
        double onsetVote = guard.voiceOnset || guard.voiceOverride ? 1.0 : 0.0;
        double speechEvidence = 0.50 * yamnetSpeechVote
                + 0.20 * webRtcVote + 0.20 * foregroundVote + 0.10 * onsetVote;

        double yamnetMusicVote = clamp01((musicRolling - 0.08) / 0.62);
        double guardMusicVote = clamp01((guard.backgroundMusicScore - 0.35) / 0.45);
        double lockedVote = guard.backgroundMusic ? 1.0 : 0.0;
        double structureVote = clamp01((guard.harmonicPersistence - 0.65) / 0.30);
        double musicEvidence = 0.45 * yamnetMusicVote
                + 0.30 * guardMusicVote + 0.15 * lockedVote + 0.10 * structureVote;

        Verdict verdict;
        String reason;
        double sendThreshold = bgmPreset ? 0.43 : 0.45;
        double suppressMusicThreshold = bgmPreset ? 0.58 : 0.68;
        double suppressSpeechCeiling = bgmPreset ? 0.34 : 0.24;
        // Extremely strict escape hatch for instrumental/BGM-only passages. It is
        // intentionally narrower than ordinary music suppression: real quiet speech
        // in our device tests raised YAMNet rolling evidence well above this floor.
        boolean strongPureMusicConsensus = bgmPreset && ready
                && musicEvidence >= 0.85 && speechRolling <= 0.015
                && !guard.voiceOnset;
        if (strongPureMusicConsensus) {
            verdict = Verdict.SUPPRESS;
            reason = "strong_pure_music_consensus";
        } else if (speechEvidence >= sendThreshold || guard.voiceOnset) {
            verdict = Verdict.SEND;
            reason = guard.voiceOnset ? "foreground_onset" : "speech_consensus";
        } else if (ready && musicEvidence >= suppressMusicThreshold
                && speechEvidence < suppressSpeechCeiling
                && !guard.voiceOverride) {
            verdict = Verdict.SUPPRESS;
            reason = guard.backgroundMusic ? "stable_music_consensus" : "music_consensus";
        } else {
            verdict = Verdict.AMBIGUOUS;
            reason = ready ? "mixed_or_weak_evidence" : "yamnet_warmup";
        }
        return new Result(speechEvidence, musicEvidence, speechRolling, musicRolling,
                ready, verdict, reason);
    }

    private static void push(ArrayDeque<Double> values, double value) {
        values.addLast(value);
        while (values.size() > 3) values.removeFirst();
    }

    private static double mean(ArrayDeque<Double> values) {
        if (values.isEmpty()) return 0;
        double sum = 0;
        for (double value : values) sum += value;
        return sum / values.size();
    }

    private static double clamp01(double value) {
        return Math.max(0, Math.min(1, value));
    }
}
