package dev.codevibes.kotoba.probe;

final class MusicGuard {
    static final class Result {
        final double backgroundMusicScore, foregroundVoiceScore;
        final double energyVariation, zcrMean, zcrVariation;
        final double spectralFlux, harmonicPersistence, rhythmPeriodicity, vadRatio;
        final double energyDelta, fluxZ, spectrumResidual, voiceBandDelta;
        final boolean backgroundMusic, backgroundReady, voiceOnset, voiceOverride, armed;
        final int overrideFrames;
        final long processingNanos;

        Result(double backgroundMusicScore, double foregroundVoiceScore,
               double energyVariation, double zcrMean, double zcrVariation,
               double spectralFlux, double harmonicPersistence, double rhythmPeriodicity,
               double vadRatio, double energyDelta, double fluxZ, double spectrumResidual,
               double voiceBandDelta, boolean backgroundMusic, boolean backgroundReady,
               boolean voiceOnset, boolean voiceOverride, boolean armed,
               int overrideFrames, long processingNanos) {
            this.backgroundMusicScore = backgroundMusicScore;
            this.foregroundVoiceScore = foregroundVoiceScore;
            this.energyVariation = energyVariation;
            this.zcrMean = zcrMean;
            this.zcrVariation = zcrVariation;
            this.spectralFlux = spectralFlux;
            this.harmonicPersistence = harmonicPersistence;
            this.rhythmPeriodicity = rhythmPeriodicity;
            this.vadRatio = vadRatio;
            this.energyDelta = energyDelta;
            this.fluxZ = fluxZ;
            this.spectrumResidual = spectrumResidual;
            this.voiceBandDelta = voiceBandDelta;
            this.backgroundMusic = backgroundMusic;
            this.backgroundReady = backgroundReady;
            this.voiceOnset = voiceOnset;
            this.voiceOverride = voiceOverride;
            this.armed = armed;
            this.overrideFrames = overrideFrames;
            this.processingNanos = processingNanos;
        }
    }

    private static final int SAMPLE_RATE = 16_000;
    private static final int FFT_SIZE = 1024;
    private static final int FRAME_HISTORY = 200;       // 4 seconds
    private static final int SCORE_UPDATE_FRAMES = 13; // about 260 ms
    private static final int OVERRIDE_HOLD_FRAMES = 25; // 500 ms; segment continuation takes over afterwards
    private static final int REARM_FRAMES = 8;          // 160 ms cooldown, independent of spectrum shape
    private static final double MUSIC_ENTER_SCORE = 0.69;
    private static final double MUSIC_EXIT_SCORE = 0.55;

    private final short[] pcm = new short[FFT_SIZE];
    private int pcmFill;
    private final double[] energy = new double[FRAME_HISTORY];
    private final double[] zcr = new double[FRAME_HISTORY];
    private final double[] flux = new double[FRAME_HISTORY];
    private final double[] persistence = new double[FRAME_HISTORY];
    private final boolean[] vad = new boolean[FRAME_HISTORY];
    private int historyCount, historyCursor, framesSinceScore;

    private double[] previousMagnitude;
    private double[] backgroundSpectrum;
    private double backgroundEnergyDb;
    private double backgroundFluxMean;
    private double backgroundFluxVariance = 0.01;
    private double backgroundVoiceBandDb;
    private boolean backgroundReady;
    private boolean backgroundMusic;
    private double backgroundMusicScore;

    private final boolean[] transientHistory = new boolean[5];
    private int transientCursor, transientCount;
    private boolean armed = true;
    private int overrideFrames;
    private int rearmQuietFrames;
    private int calibrationFrames;
    private int musicEnterUpdates;
    private int musicExitUpdates;

    Result accept(short[] frame, boolean rawVad, double db, double noiseDb,
                  boolean yamnetReady, double yamnetSpeech, double yamnetMusic) {
        long started = System.nanoTime();
        appendPcm(frame);

        double currentZcr = zeroCrossingRate(frame);
        double currentFlux = 0;
        double currentPersistence = 0;
        double currentVoiceBandDb = -120;
        double spectrumResidual = 0;
        double[] magnitude = null;
        if (pcmFill == FFT_SIZE) {
            magnitude = magnitudeSpectrum(pcm);
            currentVoiceBandDb = bandDb(magnitude, 300, 3400);
            if (previousMagnitude != null) {
                currentFlux = normalizedFlux(previousMagnitude, magnitude);
                currentPersistence = cosineSimilarity(previousMagnitude, magnitude);
            }
            if (backgroundReady) spectrumResidual = 1.0 - cosineSimilarity(backgroundSpectrum, magnitude);
            previousMagnitude = magnitude;
        }

        energy[historyCursor] = db;
        zcr[historyCursor] = currentZcr;
        flux[historyCursor] = currentFlux;
        persistence[historyCursor] = currentPersistence;
        vad[historyCursor] = rawVad;
        historyCursor = (historyCursor + 1) % FRAME_HISTORY;
        if (historyCount < FRAME_HISTORY) historyCount++;

        framesSinceScore++;
        if (framesSinceScore >= SCORE_UPDATE_FRAMES) {
            framesSinceScore = 0;
            updateBackgroundMusicScore();
        }

        if (backgroundMusic && !backgroundReady && magnitude != null) {
            backgroundSpectrum = magnitude.clone();
            backgroundEnergyDb = db;
            backgroundFluxMean = currentFlux;
            backgroundVoiceBandDb = currentVoiceBandDb;
            backgroundReady = true;
            calibrationFrames = 25;
            armed = false;
            clearTransientHistory();
        }

        double energyDelta = backgroundReady ? db - backgroundEnergyDb : 0;
        double fluxStd = Math.sqrt(Math.max(0.0025, backgroundFluxVariance));
        double fluxZ = backgroundReady ? (currentFlux - backgroundFluxMean) / fluxStd : 0;
        double voiceBandDelta = backgroundReady ? currentVoiceBandDb - backgroundVoiceBandDb : 0;

        // Raw-bin spectral residual is diagnostic only. In v0.2.2 it reacted more
        // strongly to a changing melody than to speech, so it must not veto or
        // re-arm foreground detection.
        double fluxEvidence = clamp01((fluxZ - 0.8) / 2.8);
        double bandEvidence = clamp01((voiceBandDelta - 3.0) / 14.0);
        double energyEvidence = clamp01((energyDelta - 4.0) / 16.0);
        double foregroundScore = 0.40 * fluxEvidence
                + 0.35 * bandEvidence
                + 0.15 * energyEvidence
                + 0.10 * (rawVad ? 1.0 : 0.0);

        boolean fluxAndBandEvent = fluxZ >= 1.5 && voiceBandDelta >= 6.0;
        boolean strongVoiceRise = fluxZ >= 0.8 && voiceBandDelta >= 10.0
                && energyDelta >= 8.0;
        boolean transientFrame = backgroundMusic && backgroundReady && calibrationFrames == 0
                && rawVad && (fluxAndBandEvent || strongVoiceRise);
        updateTransientHistory(transientFrame);

        boolean voiceOnset = false;
        if (armed && transientCount >= 3) {
            voiceOnset = true;
            armed = false;
            overrideFrames = OVERRIDE_HOLD_FRAMES;
            rearmQuietFrames = 0;
        }

        if (calibrationFrames > 0) {
            calibrationFrames--;
            if (calibrationFrames == 0) {
                armed = true;
                clearTransientHistory();
            }
        } else if (!armed) {
            // Rearming is a short cooldown, not a demand for the live spectrum to
            // resemble a frozen FFT snapshot. That old condition was practically
            // impossible for both music and speech.
            if (overrideFrames == 0) rearmQuietFrames++; else rearmQuietFrames = 0;
            if (rearmQuietFrames >= REARM_FRAMES) {
                armed = true;
                rearmQuietFrames = 0;
                clearTransientHistory();
            }
        }

        boolean voiceOverride = overrideFrames > 0;
        if (overrideFrames > 0) overrideFrames--;

        // The background learns slowly only when no foreground override is active.
        // This prevents a newly detected voice onset from being immediately absorbed.
        if (backgroundMusic && backgroundReady && !voiceOverride && magnitude != null) {
            boolean ordinaryLearning = calibrationFrames > 0
                    || (foregroundScore < 0.35 && transientCount == 0);
            // A song can change arrangement without becoming foreground speech. When
            // YAMNet remains strongly music-dominant, keep following that bed slowly
            // instead of freezing an old spectrum and creating a positive-feedback
            // foreground false alarm. The low alpha avoids absorbing real speech.
            boolean confirmedMusicLearning = yamnetReady
                    && yamnetMusic >= 0.70 && yamnetSpeech <= 0.05;
            if (ordinaryLearning) {
                updateBackgroundModel(magnitude, db, currentFlux, currentVoiceBandDb,
                        0.006, 0.010);
            } else if (confirmedMusicLearning) {
                updateBackgroundModel(magnitude, db, currentFlux, currentVoiceBandDb,
                        0.002, 0.003);
            }
        }

        return new Result(backgroundMusicScore, foregroundScore,
                std(energy, Math.min(historyCount, 50)),
                mean(zcr, Math.min(historyCount, 100)),
                std(zcr, Math.min(historyCount, 100)),
                mean(flux, Math.min(historyCount, 50)),
                mean(persistence, Math.min(historyCount, 100)),
                rhythmPeriodicity(), booleanMean(vad, Math.min(historyCount, 100)),
                energyDelta, fluxZ, spectrumResidual, voiceBandDelta,
                backgroundMusic, backgroundReady, voiceOnset, voiceOverride,
                armed, overrideFrames, System.nanoTime() - started);
    }

    private void updateBackgroundMusicScore() {
        int oneSecond = Math.min(historyCount, 50);
        int twoSeconds = Math.min(historyCount, 100);
        double energyStd = std(energy, oneSecond);
        double persistenceMean = mean(persistence, twoSeconds);
        double vadRatio = booleanMean(vad, twoSeconds);
        double rhythm = rhythmPeriodicity();
        double stableEnergy = 1.0 - clamp01(energyStd / 15.0);

        backgroundMusicScore = 0.35 * clamp01(persistenceMean)
                + 0.25 * vadRatio
                + 0.20 * rhythm
                + 0.20 * stableEnergy;
        if (historyCount < 75) backgroundMusicScore *= historyCount / 75.0;

        // High-confidence, sustained lock. Speech also has harmonics, therefore
        // persistence alone is never sufficient evidence of music.
        boolean supportingStructure = persistenceMean >= 0.875
                && vadRatio >= 0.78 && rhythm >= 0.28 && stableEnergy >= 0.45;
        boolean enterEvidence = historyCount >= 100
                && backgroundMusicScore >= MUSIC_ENTER_SCORE && supportingStructure;
        if (!backgroundMusic) {
            musicEnterUpdates = enterEvidence ? musicEnterUpdates + 1 : 0;
            if (musicEnterUpdates >= 3) {
                backgroundMusic = true;
                musicEnterUpdates = 0;
                musicExitUpdates = 0;
            }
        } else {
            boolean exitEvidence = backgroundMusicScore <= MUSIC_EXIT_SCORE
                    || persistenceMean < 0.78 || vadRatio < 0.48;
            musicExitUpdates = exitEvidence ? musicExitUpdates + 1 : 0;
        }
        if (backgroundMusic && musicExitUpdates >= 5) {
            backgroundMusic = false;
            backgroundReady = false;
            armed = true;
            overrideFrames = 0;
            calibrationFrames = 0;
            musicExitUpdates = 0;
            clearTransientHistory();
        }
    }

    private void updateBackgroundModel(double[] magnitude, double db,
                                       double currentFlux, double currentVoiceBandDb,
                                       double spectrumAlpha, double scalarAlpha) {
        for (int i = 0; i < magnitude.length; i++)
            backgroundSpectrum[i] += spectrumAlpha * (magnitude[i] - backgroundSpectrum[i]);
        backgroundEnergyDb += scalarAlpha * (db - backgroundEnergyDb);
        double fluxDifference = currentFlux - backgroundFluxMean;
        backgroundFluxMean += scalarAlpha * fluxDifference;
        backgroundFluxVariance += scalarAlpha * (fluxDifference * fluxDifference - backgroundFluxVariance);
        backgroundVoiceBandDb += scalarAlpha * (currentVoiceBandDb - backgroundVoiceBandDb);
    }

    private void updateTransientHistory(boolean value) {
        if (transientHistory[transientCursor]) transientCount--;
        transientHistory[transientCursor] = value;
        if (value) transientCount++;
        transientCursor = (transientCursor + 1) % transientHistory.length;
    }

    private void clearTransientHistory() {
        for (int i = 0; i < transientHistory.length; i++) transientHistory[i] = false;
        transientCursor = 0;
        transientCount = 0;
    }

    private void appendPcm(short[] frame) {
        if (pcmFill + frame.length <= FFT_SIZE) {
            System.arraycopy(frame, 0, pcm, pcmFill, frame.length);
            pcmFill += frame.length;
            return;
        }
        int overflow = pcmFill + frame.length - FFT_SIZE;
        int retained = pcmFill - overflow;
        System.arraycopy(pcm, overflow, pcm, 0, retained);
        System.arraycopy(frame, 0, pcm, retained, frame.length);
        pcmFill = FFT_SIZE;
    }

    private double rhythmPeriodicity() {
        int n = historyCount;
        if (n < 75) return 0;
        double average = mean(energy, n);
        double best = 0;
        int maxLag = Math.min(100, n / 2);
        for (int lag = 12; lag <= maxLag; lag++) {
            double numerator = 0, left = 0, right = 0;
            for (int i = 0; i < n - lag; i++) {
                double a = recent(energy, i) - average;
                double b = recent(energy, i + lag) - average;
                numerator += a * b; left += a * a; right += b * b;
            }
            if (left > 0 && right > 0) best = Math.max(best, numerator / Math.sqrt(left * right));
        }
        return clamp01(best);
    }

    private double[] magnitudeSpectrum(short[] input) {
        double[] real = new double[FFT_SIZE];
        double[] imag = new double[FFT_SIZE];
        for (int i = 0; i < FFT_SIZE; i++) {
            double hann = 0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / (FFT_SIZE - 1));
            real[i] = input[i] * hann;
        }
        fft(real, imag);
        double[] output = new double[FFT_SIZE / 2];
        for (int i = 1; i < output.length; i++) output[i] = Math.hypot(real[i], imag[i]);
        return output;
    }

    private static void fft(double[] real, double[] imag) {
        int n = real.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                double r = real[i]; real[i] = real[j]; real[j] = r;
                double m = imag[i]; imag[i] = imag[j]; imag[j] = m;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double angle = -2 * Math.PI / len;
            double wLenR = Math.cos(angle), wLenI = Math.sin(angle);
            for (int i = 0; i < n; i += len) {
                double wr = 1, wi = 0;
                for (int j = 0; j < len / 2; j++) {
                    int u = i + j, v = u + len / 2;
                    double vr = real[v] * wr - imag[v] * wi;
                    double vi = real[v] * wi + imag[v] * wr;
                    real[v] = real[u] - vr; imag[v] = imag[u] - vi;
                    real[u] += vr; imag[u] += vi;
                    double nextWr = wr * wLenR - wi * wLenI;
                    wi = wr * wLenI + wi * wLenR; wr = nextWr;
                }
            }
        }
    }

    private static double bandDb(double[] magnitude, int lowHz, int highHz) {
        int low = Math.max(1, lowHz * FFT_SIZE / SAMPLE_RATE);
        int high = Math.min(magnitude.length - 1, highHz * FFT_SIZE / SAMPLE_RATE);
        double sum = 0;
        for (int i = low; i <= high; i++) sum += magnitude[i] * magnitude[i];
        return sum > 0 ? 10.0 * Math.log10(sum / (high - low + 1)) : -120;
    }

    private double mean(double[] values, int count) {
        if (count <= 0) return 0;
        double sum = 0;
        for (int i = 0; i < count; i++) sum += recent(values, i);
        return sum / count;
    }

    private double std(double[] values, int count) {
        if (count <= 1) return 0;
        double average = mean(values, count), sum = 0;
        for (int i = 0; i < count; i++) {
            double difference = recent(values, i) - average;
            sum += difference * difference;
        }
        return Math.sqrt(sum / count);
    }

    private double booleanMean(boolean[] values, int count) {
        if (count <= 0) return 0;
        int positives = 0;
        for (int i = 0; i < count; i++) if (recent(values, i)) positives++;
        return positives / (double) count;
    }

    private double recent(double[] values, int offset) {
        return values[(historyCursor - 1 - offset + FRAME_HISTORY) % FRAME_HISTORY];
    }

    private boolean recent(boolean[] values, int offset) {
        return values[(historyCursor - 1 - offset + FRAME_HISTORY) % FRAME_HISTORY];
    }

    private static double zeroCrossingRate(short[] frame) {
        int crossings = 0;
        for (int i = 1; i < frame.length; i++)
            if ((frame[i - 1] < 0) != (frame[i] < 0)) crossings++;
        return crossings / (double) (frame.length - 1);
    }

    private static double normalizedFlux(double[] previous, double[] current) {
        double change = 0, total = 0;
        for (int i = 1; i < current.length; i++) {
            change += Math.abs(current[i] - previous[i]);
            total += current[i];
        }
        return total > 0 ? change / total : 0;
    }

    private static double cosineSimilarity(double[] a, double[] b) {
        if (a == null || b == null) return 0;
        double dot = 0, aa = 0, bb = 0;
        for (int i = 1; i < a.length; i++) {
            dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i];
        }
        return aa > 0 && bb > 0 ? dot / Math.sqrt(aa * bb) : 0;
    }

    private static double clamp01(double value) { return Math.max(0, Math.min(1, value)); }
}
